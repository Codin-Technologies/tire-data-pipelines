import json
from pyflink.datastream import StreamExecutionEnvironment, TimeCharacteristic
from pyflink.datastream.connectors.kafka import (
    FlinkKafkaConsumer, FlinkKafkaProducer
)
from pyflink.common.serialization import SimpleStringSchema
from pyflink.common.typeinfo import Types

# ------------------------------------
# Helper logic
# ------------------------------------

# Dictionary to detect tire swaps
last_positions = {}   # { (vehicle_id, tire_id): tire_position }

def detect_alerts(record):
    data = json.loads(record)
    alerts = []

    vehicle = data.get("vehicle_id")
    tire_pos = data.get("tire_position")
    pressure = float(data.get("pressure_psi"))
    temperature = float(data.get("temperature_c"))
    timestamp = data.get("timestamp")

    # -------------------------------
    # Rule 1: LOW PRESSURE
    # -------------------------------
    if pressure < 90:
        alerts.append({
            "type": "LOW_PRESSURE",
            "vehicle_id": vehicle,
            "position": tire_pos,
            "pressure": pressure,
            "temperature": temperature,
            "timestamp": timestamp
        })

    # -------------------------------
    # Rule 2: HIGH TEMPERATURE
    # -------------------------------
    if temperature > 80:
        alerts.append({
            "type": "HIGH_TEMPERATURE",
            "vehicle_id": vehicle,
            "position": tire_pos,
            "pressure": pressure,
            "temperature": temperature,
            "timestamp": timestamp
        })

    # -------------------------------
    # Rule 3: TIRE SWAP DETECTION
    # -------------------------------
    key = (vehicle, tire_pos)

    if key in last_positions and last_positions[key] != tire_pos:
        alerts.append({
            "type": "TIRE_SWAP",
            "vehicle_id": vehicle,
            "from_position": last_positions[key],
            "to_position": tire_pos,
            "timestamp": timestamp
        })

    # update last known position
    last_positions[key] = tire_pos

    return json.dumps(alerts)


# ------------------------------------
# FLINK JOB
# ------------------------------------

def main():
    env = StreamExecutionEnvironment.get_execution_environment()
    env.set_parallelism(1)

    # Kafka consumer
    consumer_props = {
        "bootstrap.servers": "kafka:9092",
        "group.id": "flink-processor"
    }

    consumer = FlinkKafkaConsumer(
        topics="tire-data",
        deserialization_schema=SimpleStringSchema(),
        properties=consumer_props
    )

    # Kafka producer
    producer = FlinkKafkaProducer(
        topic="tire.alerts",
        serialization_schema=SimpleStringSchema(),
        producer_config={"bootstrap.servers": "kafka:9092"}
    )

    # Add consumer
    stream = env.add_source(consumer)

    # Process stream
    processed = stream.map(detect_alerts, output_type=Types.STRING())

    # Debug print
    processed.print()

    # Write alerts to Kafka
    processed.add_sink(producer)

    # Execute Flink Job
    env.execute("Tire Alert Processor")


if __name__ == "__main__":
    main()
